<?
/*******************************************************************************
* CASH DESK - SHOW ICON                                                        *
*                                                                              *
* Version: 1.0                                                                 *
* Date:    21.11.2018                                                          *
* Author:  Stefano LUISE                                                       *
*******************************************************************************/
?>
<!DOCTYPE html>
<html>
<head>
<title>Head bground</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="cssnn.css" rel="stylesheet" type="text/css">

</head>

<body leftmargin="0" topmargin="23" bgcolor="#ffffff" background="img/icon_bg_grad2.gif">

<table border="0" cellpadding="0" cellspacing="0">
<tbody>
    <tr>
      <td><img src="img/blank.gif" alt="" height="1" width="10"></td>
      <td><img src="img/cash_desk.png" height="91" width="117" border="0"></td>
      <td><img src="img/blank.gif" alt="" height="1" width="50"></td>
      <td align="justify"><FONT face="Arial" size="5" color="#800080"><b></b></FONT></td>
      <td><img src="img/blank.gif" alt="" height="1" width="10"></td>
      <td align="justify"><FONT face="Arial" size="4" color="#800080"> CASH DESK -</FONT></td>
      <td><img src="img/blank.gif" alt="" height="1" width="10"></td>
      <td align="justify"><FONT face="Arial" size="4" color="#800080"> Ver. 1.0</FONT></td>
     
    </tr>
  </tbody>
</table>
<?
 echo "<table border='0' cellpadding='0' cellspacing='0'>";
 echo "<tr valign='top'>";
 echo "<td valign='top'><img src='img/icon_grad2.gif' alt='' width='1260' height='20'></td>";
 echo "</tr>";
?>
</body>
</html>
