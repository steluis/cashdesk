#!/bin/bash
numero=$1
asporto=$2
coperti=$3
stringa=$4
bash stampa.bash "$numero" "$asporto" "$coperti" "$stringa"
