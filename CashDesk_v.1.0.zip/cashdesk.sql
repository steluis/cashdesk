-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Dic 31, 2018 alle 18:17
-- Versione del server: 10.1.37-MariaDB-0+deb9u1
-- Versione PHP: 7.0.30-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cashdesk`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `blocco`
--

CREATE TABLE `blocco` (
  `id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `blocco`
--

INSERT INTO `blocco` (`id`) VALUES
(12);

-- --------------------------------------------------------

--
-- Struttura della tabella `caratteri`
--

CREATE TABLE `caratteri` (
  `id` int(10) NOT NULL,
  `charset` varchar(30) NOT NULL,
  `euro` varchar(20) NOT NULL,
  `egrave` varchar(20) NOT NULL,
  `eacuto` varchar(20) NOT NULL,
  `agrave` varchar(20) NOT NULL,
  `igrave` varchar(20) NOT NULL,
  `ograve` varchar(20) NOT NULL,
  `ugrave` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `caratteri`
--

INSERT INTO `caratteri` (`id`, `charset`, `euro`, `egrave`, `eacuto`, `agrave`, `igrave`, `ograve`, `ugrave`) VALUES
(1, 'unicode', '\\x80', '\\xa8\\xa8', '\\xa8\\xa6', '\\xa8\\xa4', '\\xa8\\xac', '\\xa8\\xb0', '\\xa8\\xb4'),
(2, 'CP858', '\\xd5 ', '\\x8a ', '\\x82 ', '\\x85 ', '\\x8d ', '\\x95 ', '\\x97 ');

-- --------------------------------------------------------

--
-- Struttura della tabella `listino`
--

CREATE TABLE `listino` (
  `id` int(11) NOT NULL,
  `descrizione` varchar(100) NOT NULL,
  `importo` float(4,2) NOT NULL,
  `posizione` varchar(10) NOT NULL,
  `tipo_piatto` varchar(10) NOT NULL,
  `disponibile` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `listino`
--

INSERT INTO `listino` (`id`, `descrizione`, `importo`, `posizione`, `tipo_piatto`, `disponibile`) VALUES
(17, 'ESPORTAZIONE', 0.00, 'basso', 'bar', '1'),
(10, 'Coca cola', 2.00, 'alto', 'primo', '1'),
(8, 'Patatine fritte', 2.00, 'alto', 'primo', '1'),
(7, 'Insalata mista', 2.00, 'alto', 'primo', '1'),
(6, 'Affettati misti', 5.00, 'alto', 'primo', '1'),
(5, 'Panino caldo', 4.00, 'alto', 'primo', '1'),
(3, 'Panino', 3.00, 'alto', 'primo', '1'),
(2, 'Piadina', 3.50, 'alto', 'primo', '1'),
(1, 'Tostone', 3.00, 'alto', 'primo', '1'),
(13, 'Vino bottiglia', 5.00, 'alto', 'primo', '1'),
(9, 'The bottiglia', 1.50, 'alto', 'primo', '1'),
(12, 'Vino bicchiere', 1.00, 'alto', 'primo', '1'),
(11, 'Birra', 2.00, 'alto', 'primo', '1'),
(14, 'Prosecco bicchiere', 1.00, 'alto', 'primo', '1'),
(15, 'Dolce', 3.00, 'basso', 'bar', '1'),
(16, 'Caffè', 1.00, 'basso', 'bar', '1'),
(4, 'Piadina', 3.00, 'alto', 'primo', '1');

-- --------------------------------------------------------

--
-- Struttura della tabella `parametri`
--

CREATE TABLE `parametri` (
  `id` int(11) NOT NULL,
  `descrizione` varchar(50) NOT NULL,
  `valore` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `parametri`
--

INSERT INTO `parametri` (`id`, `descrizione`, `valore`) VALUES
(1, 'numero_scontrino', '18'),
(2, 'stampante_cucina', 'Samsung-ML-2010'),
(3, 'stampante_cassa', 'Samsung-ML-2010'),
(4, 'logo', 'Presepe.png'),
(5, 'intestazione', 'ASD SPORT PER TUTTI'),
(6, 'scontrino_bar', '0'),
(7, 'intestazione2', ''),
(8, 'ultimo_indice', '17'),
(9, 'abilita_stampa_cucina', '1');

-- --------------------------------------------------------

--
-- Struttura della tabella `scontrini`
--

CREATE TABLE `scontrini` (
  `coperti` varchar(100) NOT NULL,
  `scontrino` varchar(10) NOT NULL,
  `nullo` int(5) NOT NULL DEFAULT '0',
  `descrizione` varchar(50) NOT NULL,
  `qta` varchar(10) NOT NULL,
  `importo` varchar(10) NOT NULL,
  `tipo_piatto` varchar(30) NOT NULL,
  `cassiere` varchar(30) NOT NULL,
  `data` date NOT NULL,
  `ora` varchar(20) NOT NULL,
  `note` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `scontrini`
--

INSERT INTO `scontrini` (`coperti`, `scontrino`, `nullo`, `descrizione`, `qta`, `importo`, `tipo_piatto`, `cassiere`, `data`, `ora`, `note`) VALUES
('1', '1', 1, 'Piadina', '2', '7', 'primo', 'utente1', '2018-12-24', '11:08:27', ''),
('1', '2', 0, 'Affettati misti', '1', '5', 'primo', 'utente1', '2018-12-24', '11:13:21', ''),
('1', '2', 0, 'Panino caldo', '1', '4', 'primo', 'utente1', '2018-12-24', '11:13:21', ''),
('1', '2', 0, 'Panino', '2', '6', 'primo', 'utente1', '2018-12-24', '11:13:21', ''),
('1', '2', 0, 'Piadina', '1', '3.5', 'primo', 'utente1', '2018-12-24', '11:13:21', ''),
('1', '2', 0, 'Tostone', '3', '9', 'primo', 'utente1', '2018-12-24', '11:13:21', ''),
('1', '3', 0, 'Piadina', '2', '7', 'primo', 'utente1', '2018-12-24', '11:30:21', ''),
('1', '3', 0, 'Tostone', '3', '9', 'primo', 'utente1', '2018-12-24', '11:30:21', ''),
('1', '4', 0, 'Panino', '1', '3', 'primo', 'utente1', '2018-12-24', '11:35:44', ''),
('1', '4', 0, 'Piadina', '2', '7', 'primo', 'utente1', '2018-12-24', '11:35:44', ''),
('1', '4', 0, 'Tostone', '1', '3', 'primo', 'utente1', '2018-12-24', '11:35:44', ''),
('1', '5', 0, 'Panino', '2', '6', 'primo', 'utente2', '2018-12-24', '11:37:25', ''),
('1', '5', 0, 'Piadina', '3', '10.5', 'primo', 'utente2', '2018-12-24', '11:37:25', ''),
('1', '5', 0, 'Tostone', '1', '3', 'primo', 'utente2', '2018-12-24', '11:37:25', ''),
('1', '5', 0, 'Caffè', '2', '2', 'bar', 'utente2', '2018-12-24', '11:37:25', ''),
('1', '6', 0, 'Piadina', '2', '7', 'primo', 'utente2', '2018-12-24', '11:38:04', ''),
('1', '7', 0, 'Affettati misti', '2', '10', 'primo', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '7', 0, 'Panino caldo', '1', '4', 'primo', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '7', 0, 'Panino', '2', '6', 'primo', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '7', 0, 'Piadina', '2', '7', 'primo', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '7', 0, 'Tostone', '1', '3', 'primo', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '7', 0, 'Dolce', '1', '3', 'bar', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '7', 0, 'Caffè', '2', '2', 'bar', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '7', 0, 'ESPORTAZIONE', '1', '0.00', 'secondo', 'utente1', '2018-12-24', '12:20:38', ''),
('1', '8', 0, 'Piadina', '3', '10.5', 'primo', 'utente1', '2018-12-24', '14:39:49', ''),
('1', '8', 0, 'Tostone', '1', '3', 'primo', 'utente1', '2018-12-24', '14:39:49', ''),
('1', '8', 0, 'Caffè', '3', '3', 'bar', 'utente1', '2018-12-24', '14:39:49', ''),
('1', '9', 0, 'Panino', '3', '9', 'primo', 'utente1', '2018-12-24', '14:40:43', ''),
('1', '9', 0, 'Piadina', '3', '10.5', 'primo', 'utente1', '2018-12-24', '14:40:43', ''),
('1', '9', 0, 'Tostone', '2', '6', 'primo', 'utente1', '2018-12-24', '14:40:43', ''),
('1', '9', 0, 'Prosecco bicchiere', '3', '3', 'primo', 'utente1', '2018-12-24', '14:40:43', ''),
('1', '9', 0, 'Caffè', '4', '4', 'bar', 'utente1', '2018-12-24', '14:40:43', ''),
('1', '10', 0, 'Piadina', '1', '3.5', 'primo', 'utente1', '2018-12-24', '14:41:21', ''),
('1', '11', 0, 'Piadina', '3', '10.5', 'primo', 'utente3', '2018-12-24', '15:01:18', ''),
('1', '11', 0, 'Tostone', '1', '3', 'primo', 'utente3', '2018-12-24', '15:01:18', ''),
('2', '12', 0, 'Affettati misti', '2', '10', 'primo', 'utente1', '2018-12-24', '15:14:22', 'Solo salame'),
('2', '12', 0, 'Panino caldo', '1', '4', 'primo', 'utente1', '2018-12-24', '15:14:22', ''),
('2', '12', 0, 'Panino', '1', '3', 'primo', 'utente1', '2018-12-24', '15:14:22', ''),
('2', '12', 0, 'Piadina', '1', '3.5', 'primo', 'utente1', '2018-12-24', '15:14:22', ''),
('2', '12', 0, 'Tostone', '2', '6', 'primo', 'utente1', '2018-12-24', '15:14:22', ''),
('2', '12', 0, 'Dolce', '1', '3', 'bar', 'utente1', '2018-12-24', '15:14:22', ''),
('2', '12', 0, 'Caffè', '1', '1', 'bar', 'utente1', '2018-12-24', '15:14:22', ''),
('2', '12', 0, 'ESPORTAZIONE', '1', '0.00', 'secondo', 'utente1', '2018-12-24', '15:14:22', ''),
('2', '13', 0, 'Affettati misti', '1', '5', 'primo', 'utente1', '2018-12-28', '22:58:11', ''),
('2', '13', 0, 'Panino', '1', '3', 'primo', 'utente1', '2018-12-28', '22:58:11', ''),
('2', '13', 0, 'Piadina', '1', '3.5', 'primo', 'utente1', '2018-12-28', '22:58:11', ''),
('2', '13', 0, 'Tostone', '1', '3', 'primo', 'utente1', '2018-12-28', '22:58:11', ''),
('2', '13', 0, 'Dolce', '1', '3', 'bar', 'utente1', '2018-12-28', '22:58:11', ''),
('2', '13', 0, 'Caffè', '1', '1', 'bar', 'utente1', '2018-12-28', '22:58:11', ''),
('2', '13', 0, 'ESPORTAZIONE', '1', '0.00', 'secondo', 'utente1', '2018-12-28', '22:58:11', ''),
('1', '14', 0, 'Patatine fritte', '1', '2', 'primo', 'utente1', '2018-12-28', '22:58:32', ''),
('1', '14', 0, 'Insalata mista', '1', '2', 'primo', 'utente1', '2018-12-28', '22:58:32', ''),
('1', '14', 0, 'The bottiglia', '1', '1.5', 'primo', 'utente1', '2018-12-28', '22:58:32', ''),
('1', '14', 0, 'Birra', '1', '2', 'primo', 'utente1', '2018-12-28', '22:58:32', ''),
('1', '14', 0, 'Dolce', '1', '3', 'bar', 'utente1', '2018-12-28', '22:58:32', ''),
('1', '15', 0, 'Tostone', '1', '3', 'primo', 'utente1', '2018-12-29', '12:18:26', ''),
('1', '15', 0, 'Vino bicchiere', '1', '1', 'primo', 'utente1', '2018-12-29', '12:18:26', ''),
('1', '15', 0, 'Caffè', '1', '1', 'bar', 'utente1', '2018-12-29', '12:18:26', ''),
('1', '16', 0, 'Piadina', '1', '3.5', 'primo', 'utente1', '2018-12-29', '12:18:43', ''),
('1', '16', 0, 'Birra', '1', '2', 'primo', 'utente1', '2018-12-29', '12:18:43', ''),
('1', '17', 0, 'Patatine fritte', '1', '2', 'primo', 'utente1', '2018-12-29', '12:19:01', ''),
('1', '17', 0, 'Panino', '2', '6', 'primo', 'utente1', '2018-12-29', '12:19:01', ''),
('1', '17', 0, 'Caffè', '1', '1', 'bar', 'utente1', '2018-12-29', '12:19:01', ''),
('1', '17', 0, 'ESPORTAZIONE', '1', '0.00', 'secondo', 'utente1', '2018-12-29', '12:19:01', ''),
('1', '18', 1, 'Tostone', '1', '3', 'primo', 'utente1', '2018-12-31', '15:26:31', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `stampanti`
--

CREATE TABLE `stampanti` (
  `id` int(11) NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `cucina` varchar(10) NOT NULL,
  `formatocarta` varchar(10) NOT NULL,
  `connessione` varchar(10) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `prodID` varchar(10) NOT NULL,
  `vendID` varchar(10) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `codec` varchar(20) NOT NULL DEFAULT 'CP858'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `stampanti`
--

INSERT INTO `stampanti` (`id`, `tipo`, `cucina`, `formatocarta`, `connessione`, `ip`, `prodID`, `vendID`, `nome`, `codec`) VALUES
(67, 'Canon-MX470-series', '0', 'A5', '', '', '', '', 'Canon', ''),
(72, 'ESC-POS', '0', 'POS56', 'USB', '', '0416', '5011', 'Issy', 'CP858'),
(74, 'ESC-POS', '1', 'POS80', 'USB', '', '0483', '5743', 'POS80mm', 'unicode'),
(76, 'ESC-POS', '0', 'POS80', 'USB', '', '04b8', '0202', 'TMT86FII', 'CP858');

-- --------------------------------------------------------

--
-- Struttura della tabella `users`
--

CREATE TABLE `users` (
  `id` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `group` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `function` varchar(4) COLLATE latin1_general_ci NOT NULL,
  `role` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `nome` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `CrDate` date NOT NULL,
  `e_mail` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `logon` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `SEC` double DEFAULT NULL,
  `customer_chk` varchar(10) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dump dei dati per la tabella `users`
--

INSERT INTO `users` (`id`, `password`, `group`, `function`, `role`, `nome`, `CrDate`, `e_mail`, `logon`, `SEC`, `customer_chk`) VALUES
('utente1', 'b88d6b04a9dc38860301f6bdd81e5ccd', 'admin', 'AM', '1000000000', 'Utente1', '2012-08-30', NULL, 'off', 1546275474, NULL),
('utente2', 'f7a88d7c3168218b580aa68ab3030491', 'admin', 'AM', '1000000000', 'Utente2', '2012-08-30', NULL, 'off', 1546038361, NULL),
('utente3', 'd3dc39b29f873ec94631cdbe4e92dbf7', 'admin', 'AM', '1000000000', 'Utente3', '2012-08-30', NULL, 'on', 1546038375, NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `caratteri`
--
ALTER TABLE `caratteri`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `listino`
--
ALTER TABLE `listino`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `parametri`
--
ALTER TABLE `parametri`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `stampanti`
--
ALTER TABLE `stampanti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `caratteri`
--
ALTER TABLE `caratteri`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT per la tabella `parametri`
--
ALTER TABLE `parametri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT per la tabella `stampanti`
--
ALTER TABLE `stampanti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
